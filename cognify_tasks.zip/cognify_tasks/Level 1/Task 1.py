def reverse_string(s):
    return s[ ::-1]
input_string = input("enter the string: ")
output_string = reverse_string(input_string)
print("reverse of the input_string: ",output_string)

#OUTPUT
'''enter the string: Hello World
reverse of the input_string:  dlroW olleH'''